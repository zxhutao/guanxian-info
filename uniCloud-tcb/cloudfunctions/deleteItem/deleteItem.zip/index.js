const cloud = require('wx-server-sdk');

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

const db = cloud.database();

exports.main = async (event, context) => {
  const { type, id } = event;
  const { OPENID } = cloud.getWXContext();
  
  if (!OPENID) {
    return {
      code: -1,
      message: '请先登录'
    };
  }
  
  if (!type || !id) {
    return {
      code: -1,
      message: '参数错误'
    };
  }
  
  // 定义允许的集合类型
  const validTypes = ['jobs', 'services', 'nursing', 'house', 'carpool', 'news'];
  if (!validTypes.includes(type)) {
    return {
      code: -1,
      message: '无效的删除类型'
    };
  }
  
  try {
    // 查询记录是否存在且属于当前用户
    const { data } = await db.collection(type).doc(id).get();
    
    if (!data) {
      return {
        code: -1,
        message: '记录不存在'
      };
    }
    
    // 验证权限（只有发布者或管理员可以删除）
    if (data._openid !== OPENID) {
      return {
        code: -1,
        message: '无权删除此记录'
      };
    }
    
    // 执行删除
    await db.collection(type).doc(id).remove();
    
    return {
      code: 0,
      message: '删除成功'
    };
  } catch (err) {
    console.error('删除失败:', err);
    return {
      code: -1,
      message: '删除失败，请稍后重试'
    };
  }
};
